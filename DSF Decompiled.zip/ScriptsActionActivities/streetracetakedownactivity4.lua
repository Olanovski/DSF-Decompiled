cards = cards or {}
cards.Missions = cards.Missions or {}
cards.Missions.StreetraceTakedownActivity4 = {
  FileVersion = "2",
  name = "StreetraceTakedownActivity4",
  title = "ID:244226",
  MissionID = "22224",
  description = "ID:184367",
  cardInstances = {
    Actors = {
      Racer2 = {
        [1] = {
          lockedToPlayer = true,
          wrongWayIndicator = false,
          unableToStartFelonies = false,
          forceHighLodAi = false,
          matchTrafficSpeed = false,
          obeyRaceTowingRules = true,
          aiIgnorePlayers = false,
          desiredSpeed = 75,
          team = {
            instance = 1,
            type = "Teams",
            name = "Race Team"
          },
          drivingSkill = "Average",
          disablePanelDetach = false,
          characters = {
            instance = 1,
            type = "Characters",
            name = "Racer 2"
          },
          forceHighLodCharacters = false,
          wanderType = "random",
          selfRightIfOverturned = false,
          maintainLane = false,
          whenSpawned = "On mission start",
          vehicleTrailerId = -1,
          noOccupants = false,
          takeNonPlayerDamage = false,
          isMultiplayerActor = false,
          avoidUTurns = false,
          aiIgnorePlayerInCivsUntilHit = true,
          collisionResilience = "Average",
          raceManagerRoute = false,
          shaderParam = 3,
          spawnType = {
            instance = 1,
            type = "SpawnTypes",
            name = "New Positions"
          },
          vehicleId = 285,
          rubberbandingToPlayerStrength = "Medium",
          enableSiren = false,
          spawnSpeed = 80,
          enableSimulationArea = false,
          damageMultiplier = 1.2,
          attackStationaryVehicle = false,
          distanceBehindPlayer = -40,
          reactionTime = "Average",
          avoidedByCivilianTraffic = false,
          stayInLockedArea = false,
          blockTow = false,
          ignoreOtherAis = false,
          avoidAttacks = false,
          ignoreCivilianTraffic = false,
          routeName = "StreetraceTakedownActivity4Route",
          unaffectedByRaceSpeedTweaks = false
        },
        ["name"] = "Actor"
      },
      Racer4 = {
        [1] = {
          lockedToPlayer = true,
          wrongWayIndicator = false,
          unableToStartFelonies = false,
          forceHighLodAi = false,
          matchTrafficSpeed = false,
          obeyRaceTowingRules = true,
          aiIgnorePlayers = false,
          desiredSpeed = 110,
          team = {
            instance = 1,
            type = "Teams",
            name = "Race Team"
          },
          drivingSkill = "Average",
          disablePanelDetach = false,
          characters = {
            instance = 1,
            type = "Characters",
            name = "Racer 4"
          },
          forceHighLodCharacters = false,
          wanderType = "random",
          selfRightIfOverturned = false,
          maintainLane = false,
          whenSpawned = "On mission start",
          vehicleTrailerId = -1,
          noOccupants = false,
          takeNonPlayerDamage = false,
          isMultiplayerActor = false,
          avoidUTurns = false,
          aiIgnorePlayerInCivsUntilHit = true,
          collisionResilience = "Average",
          raceManagerRoute = false,
          shaderParam = 6,
          spawnType = {
            instance = 1,
            type = "SpawnTypes",
            name = "New Positions"
          },
          vehicleId = 287,
          rubberbandingToPlayerStrength = "Medium",
          enableSiren = false,
          spawnSpeed = 70,
          enableSimulationArea = false,
          damageMultiplier = 1.6,
          attackStationaryVehicle = false,
          distanceBehindPlayer = -30,
          reactionTime = "Average",
          avoidedByCivilianTraffic = false,
          stayInLockedArea = false,
          blockTow = false,
          ignoreOtherAis = false,
          avoidAttacks = false,
          ignoreCivilianTraffic = false,
          routeName = "StreetraceTakedownActivity4Route",
          unaffectedByRaceSpeedTweaks = false
        },
        ["name"] = "Actor"
      },
      Racer1 = {
        [1] = {
          lockedToPlayer = true,
          wrongWayIndicator = false,
          unableToStartFelonies = false,
          forceHighLodAi = false,
          matchTrafficSpeed = false,
          obeyRaceTowingRules = true,
          aiIgnorePlayers = false,
          desiredSpeed = 95,
          team = {
            instance = 1,
            type = "Teams",
            name = "Race Team"
          },
          drivingSkill = "Average",
          disablePanelDetach = false,
          characters = {
            instance = 1,
            type = "Characters",
            name = "Racer 1"
          },
          forceHighLodCharacters = false,
          wanderType = "random",
          selfRightIfOverturned = false,
          maintainLane = false,
          whenSpawned = "On mission start",
          vehicleTrailerId = -1,
          noOccupants = false,
          takeNonPlayerDamage = false,
          isMultiplayerActor = false,
          avoidUTurns = false,
          aiIgnorePlayerInCivsUntilHit = true,
          collisionResilience = "Average",
          raceManagerRoute = false,
          shaderParam = 5,
          spawnType = {
            instance = 1,
            type = "SpawnTypes",
            name = "New Positions"
          },
          vehicleId = 285,
          rubberbandingToPlayerStrength = "Medium",
          enableSiren = false,
          spawnSpeed = 70,
          enableSimulationArea = false,
          damageMultiplier = 1.2,
          attackStationaryVehicle = false,
          distanceBehindPlayer = -50,
          reactionTime = "Average",
          avoidedByCivilianTraffic = false,
          stayInLockedArea = false,
          blockTow = false,
          ignoreOtherAis = false,
          avoidAttacks = false,
          ignoreCivilianTraffic = false,
          routeName = "StreetraceTakedownActivity4Route",
          unaffectedByRaceSpeedTweaks = false
        },
        ["name"] = "Actor"
      },
      Racer3 = {
        [1] = {
          lockedToPlayer = true,
          wrongWayIndicator = false,
          unableToStartFelonies = false,
          forceHighLodAi = false,
          matchTrafficSpeed = false,
          obeyRaceTowingRules = true,
          aiIgnorePlayers = false,
          desiredSpeed = 115,
          team = {
            instance = 1,
            type = "Teams",
            name = "Race Team"
          },
          drivingSkill = "Average",
          disablePanelDetach = false,
          characters = {
            instance = 1,
            type = "Characters",
            name = "Racer 3"
          },
          forceHighLodCharacters = false,
          wanderType = "random",
          selfRightIfOverturned = false,
          maintainLane = false,
          whenSpawned = "On mission start",
          vehicleTrailerId = -1,
          noOccupants = false,
          takeNonPlayerDamage = false,
          isMultiplayerActor = false,
          avoidUTurns = false,
          aiIgnorePlayerInCivsUntilHit = true,
          collisionResilience = "Average",
          raceManagerRoute = false,
          shaderParam = 9,
          spawnType = {
            instance = 1,
            type = "SpawnTypes",
            name = "New Positions"
          },
          vehicleId = 287,
          rubberbandingToPlayerStrength = "Medium",
          enableSiren = false,
          spawnSpeed = 70,
          enableSimulationArea = false,
          damageMultiplier = 1.6,
          attackStationaryVehicle = false,
          distanceBehindPlayer = -30,
          reactionTime = "Average",
          avoidedByCivilianTraffic = false,
          stayInLockedArea = false,
          blockTow = false,
          ignoreOtherAis = false,
          avoidAttacks = true,
          ignoreCivilianTraffic = false,
          routeName = "StreetraceTakedownActivity4Route",
          unaffectedByRaceSpeedTweaks = false
        },
        ["name"] = "Actor"
      },
      Chaser = {
        [1] = {
          lockedToPlayer = false,
          wrongWayIndicator = false,
          unableToStartFelonies = false,
          forceHighLodAi = false,
          matchTrafficSpeed = false,
          obeyRaceTowingRules = false,
          aiIgnorePlayers = false,
          ignoreCivilianTraffic = false,
          team = {
            instance = 1,
            type = "Teams",
            name = "Chase Team"
          },
          drivingSkill = "Average",
          disablePanelDetach = false,
          characters = {
            instance = 1,
            type = "Characters",
            name = "Tanner"
          },
          forceHighLodCharacters = false,
          wanderType = "random",
          selfRightIfOverturned = true,
          maintainLane = false,
          whenSpawned = "On warmup",
          tailingDistance = 15,
          vehicleTrailerId = -1,
          noOccupants = false,
          takeNonPlayerDamage = false,
          warmupType = {
            instance = 1,
            type = "WarmupTypes",
            name = "New Static to rolling"
          },
          enableSiren = true,
          avoidUTurns = false,
          avoidedByCivilianTraffic = false,
          collisionResilience = "Average",
          ignoreOtherAis = false,
          spawnType = {
            instance = 1,
            type = "SpawnTypes",
            name = "New Set position 2"
          },
          vehicleId = 271,
          enableSimulationArea = false,
          spawnSpeed = 30,
          isMultiplayerActor = false,
          damageMultiplier = 0.5,
          attackStationaryVehicle = false,
          aiIgnorePlayerInCivsUntilHit = false,
          previewMovie = "Preview",
          routeName = "StreetraceTakedownActivity4Route",
          raceManagerRoute = true,
          stayInLockedArea = false,
          blockTow = false,
          reactionTime = "Average",
          avoidAttacks = false,
          groupAggression = "High",
          desiredSpeed = 80,
          unaffectedByRaceSpeedTweaks = false
        },
        ["name"] = "Actor"
      }
    },
    Characters = {
      ["Racer 2"] = {
        [1] = {
          ["Driver id"] = "-460911667"
        },
        ["name"] = "Character"
      },
      ["Racer 5"] = {
        [1] = {
          ["Driver id"] = "-1496449035"
        },
        ["name"] = "Character"
      },
      ["Tanner"] = {
        [1] = {
          ["Driver id"] = "781923877"
        },
        ["name"] = "Character"
      },
      ["Racer 3"] = {
        [1] = {
          ["Driver id"] = "-794042827"
        },
        ["name"] = "Character"
      },
      ["Racer 4"] = {
        [1] = {
          ["Driver id"] = "1989331258"
        },
        ["name"] = "Character"
      },
      ["Racer 1"] = {
        [1] = {
          ["Driver id"] = "-1907691761"
        },
        ["name"] = "Character"
      }
    },
    MissionSettings = {
      ["New MissionSettings"] = {
        [1] = {
          ["Disable auto-zap out on mission complete"] = false,
          ["Enable traffic at mission end"] = true,
          ["disablePlayerIgnoring"] = false,
          ["Spawn type"] = "Always active",
          ["Delete task object on reject preview"] = false,
          ["Start location"] = "StreetraceTakedownActivity4",
          ["Disable traffic"] = false
        },
        ["name"] = "MissionSettings"
      }
    },
    Teams = {
      ["Chase Team"] = {
        [1] = {},
        ["name"] = "Team"
      },
      ["Race Team"] = {
        [1] = {},
        ["name"] = "Team"
      }
    },
    SpawnTypes = {
      ["New Set position 2"] = {
        [1] = {
          ["Spawn location"] = "StreetraceTakedownActivity4Player",
          ["Snap to closest road"] = false
        },
        ["name"] = "Set position"
      },
      ["New Positions"] = {
        [1] = {
          ["1"] = "Racer1",
          ["4"] = "Racer4",
          ["3"] = "Racer3",
          ["2"] = "Racer2"
        },
        ["name"] = "Positions"
      }
    },
    WarmupTypes = {
      ["New Static to rolling"] = {
        [1] = {
          forceZapToVehicleFromPlayerVehicle = false,
          forceZapToVehicle = false,
          forceMissionAccept = false,
          lookToVehicle = false
        },
        ["name"] = "Static to rolling"
      }
    },
    FelonySettings = {
      ["New FelonySettings 4"] = {
        [1] = {disablePoliceInTrafficDuringMission = true},
        ["name"] = "FelonySettings"
      }
    },
    MissionInfos = {
      ["New Title and description"] = {
        [1] = {
          ["Failure reason"] = "ID:184369",
          ["missionMarkers"] = {
            [1] = {
              value = "Opponent (objective)",
              cardName = "Racer3",
              cardType = "Actor"
            },
            [2] = {
              value = "Opponent (objective)",
              cardName = "Racer2",
              cardType = "Actor"
            },
            [3] = {
              value = "Opponent (objective)",
              cardName = "Racer4",
              cardType = "Actor"
            },
            [4] = {
              value = "Opponent (objective)",
              cardName = "Racer1",
              cardType = "Actor"
            },
            [5] = {
              value = "Objective",
              cardName = "Chaser",
              cardType = "Actor"
            }
          },
          ["showRouteArrows"] = "All",
          ["1 Text"] = "ID:184367"
        },
        ["name"] = "Title and description"
      }
    },
    MissionTypes = {
      ["New Streetracer takedown activity"] = {
        [1] = {
          ["Chase team"] = {
            instance = 1,
            type = "Teams",
            name = "Chase Team"
          },
          ["Race team"] = {
            instance = 1,
            type = "Teams",
            name = "Race Team"
          }
        },
        ["name"] = "Streetracer takedown activity"
      }
    }
  }
}
